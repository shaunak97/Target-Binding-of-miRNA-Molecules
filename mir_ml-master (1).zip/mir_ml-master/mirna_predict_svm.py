#Prediction using SVM regression algorithm


import pandas as pd
import matplotlib.pyplot as plt
from sklearn.utils import shuffle
from sklearn.feature_selection import SelectKBest
from sklearn.feature_selection import chi2
import numpy as np
import seaborn as sns

  #Read the csv file as dataframes

df = pd.read_csv('full_dataset_selected_features_v01.csv')

  #Data split into feature vector and target 

X=df.iloc[:,0:10].values
y=df['positive'].values
x=df.iloc[:,1:9]


  #Feature Selection

bestfeatures=SelectKBest(score_func=chi2,k='all')
fit = bestfeatures.fit(x,y)
dfscores = pd.DataFrame(fit.scores_)
dfcolumns = pd.DataFrame(x.columns)

  #concat two dataframes for better visualization 
featureScores = pd.concat([dfcolumns,dfscores],axis=1)
  #naming the dataframe columns
featureScores.columns = ['Specs','Score']
  #print 8 best features
print(featureScores.nlargest(8,'Score'))

  
  #Correlation heatmap 
  
import seaborn as sns
#get correlations of each features in dataset
corrmat = df.corr()
top_corr_features = corrmat.index
plt.figure(figsize=(11,11))

  #plot heat map
g=sns.heatmap(df[top_corr_features].corr(),annot=True,cmap="RdYlGn")

#Dataset Split into Test and Train
from sklearn.model_selection import train_test_split
X_train,X_test,y_train,y_test = train_test_split(X,y,test_size=0.1,random_state=0)

  #Feature Scaling
from sklearn.preprocessing import StandardScaler
sc_X=StandardScaler()
X_train=sc_X.fit_transform(X_train)
X_test=sc_X.transform(X_test)
#sc_y=StandardScaler()
#y_train=sc_y.fit_transform(y_train)


  #Fitting SVR to the dataset

from sklearn.svm import SVC
from sklearn.metrics import accuracy_score

clf = SVC(kernel='linear')
clf.fit(X_train,y_train)
y_pred = clf.predict(X_test)
print(accuracy_score(y_test,y_pred))

clf = SVC(kernel='rbf')
clf.fit(X_train,y_train)
y_pred = clf.predict(X_test)
print(accuracy_score(y_test,y_pred))

  #Visualizing the SVR results
#plt.scatter(X_train, y_train, color='red')
plt.plot(X_train,clf.predict(X_train), color='blue')
plt.show()












